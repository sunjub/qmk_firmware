# IIICC

![IIICC](https://i.imgur.com/gILgpj1.jpg)

3 piece split keyboard

* Keyboard Maintainer: [kbjunky](https://github.com/kbjunky)
* Hardware Supported: IIICC PCB
* Hardware Availability: https://github.com/kbjunky/IIICC/

Make example for this keyboard (after setting up your build environment):

    make IIICC:default

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).
